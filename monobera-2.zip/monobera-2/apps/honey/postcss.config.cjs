module.exports = require("@bera/tailwind-config/postcss");
