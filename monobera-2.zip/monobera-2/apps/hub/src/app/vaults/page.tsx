import React from "react";

import Gauge from "./components/gauge";

export default function Page() {
  return <Gauge />;
}
