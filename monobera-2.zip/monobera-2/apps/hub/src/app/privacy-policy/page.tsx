import { PrivacyPolicy } from "@bera/shared-ui";

export default function Page() {
  return <PrivacyPolicy />;
}
