import { AccessDeny } from "@bera/shared-ui";

export default function Page() {
  return (
    <div>
      <AccessDeny />
    </div>
  );
}
