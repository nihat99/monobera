import { useMemo } from "react";

export const useCrocPoolNativeBera = (
  baseTokenAddress: any,
  baseTokenDecimals: any,
  quoteTokenAddress: any,
  quoteTokenDecimals: any,
): undefined => {
  return useMemo(() => {
    return undefined;
  }, [
    baseTokenAddress,
    baseTokenDecimals,
    quoteTokenAddress,
    quoteTokenDecimals,
  ]);
};
